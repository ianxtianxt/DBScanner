# DBScanner
自动扫描内网常见sql、no-sql数据库脚本(mysql、mssql、oracle、postgresql、redis、mongodb、memcached、elasticsearch)，包含未授权访问及常规弱口令检测

![](https://github.com/se55i0n/DBScanner/blob/master/scan.png)
